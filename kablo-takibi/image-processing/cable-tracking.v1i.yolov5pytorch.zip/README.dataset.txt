# row cable tracking > 2025-07-26 10:52pm
https://universe.roboflow.com/row-cable-tracking/row-cable-tracking-c115k

Provided by a Roboflow user
License: CC BY 4.0

