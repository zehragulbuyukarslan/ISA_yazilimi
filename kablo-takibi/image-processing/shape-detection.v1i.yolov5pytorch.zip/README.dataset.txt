# shape-detection > 2025-07-29 3:03pm
https://universe.roboflow.com/row-cable-tracking/shape-detection-nt3ap

Provided by a Roboflow user
License: CC BY 4.0

